-- To allow the DBA/Analysts to check whether the sessions cursor cache or
-- open cursors are really a constraint and then increase the parameter 
-- session_cached_cursors or open_cursors accordingly.
-- 
-- SESSION_CACHED_CURSORS lets you specify the number of session cursors to cache.
-- Repeated parse calls of the same SQL statement cause the session cursor for 
-- that statement to be moved into the session cursor cache. 
-- Subsequent parse calls will find the cursor in the cache and do not need to 
-- reopen the cursor and even do a soft parse.
-- 
-- The session cursor cache can be constrained by either the session_cached_cursors
-- parameter, or the open_cursors parameter. This script reports the current 
-- maximum usage in any session with respect to these limits.
-- 
-- If either of the Usage column figures approaches 100%, then the corresponding 
-- parameter should normally be increased.

select
  'session_cached_cursors'  parameter,
  lpad(value, 5)  value,
  decode(value, 0, '  n/a', to_char(100 * used / value, '990') || '%')  usage
from
  ( select
      max(s.value)  used
    from
      v$statname  n,
      v$sesstat  s
    where
      n.name = 'session cursor cache count' and
      s.statistic# = n.statistic#
  ),
  ( select
      value
    from
      v$parameter
    where
      name = 'session_cached_cursors'
  )
union all
select
  'open_cursors',
  lpad(value, 5),
  to_char(100 * used / value,  '990') || '%'
from
  ( select
      max(sum(s.value))  used
    from
      v$statname  n,
      v$sesstat  s
    where
      n.name in ('opened cursors current', 'session cursor cache count') and
      s.statistic# = n.statistic#
    group by
      s.sid
  ),
  ( select
      value
    from
      v$parameter
    where
      name = 'open_cursors'
  )
/
