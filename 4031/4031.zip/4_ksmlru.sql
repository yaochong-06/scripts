SELECT *FROM x$ksmlru 
WHERE ksmlrnum>0;
